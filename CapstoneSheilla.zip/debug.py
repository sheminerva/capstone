from send_email import extract_summary
import fire

if __name__ == '__main__':
  # Export to Fire
  fire.Fire(extract_summary)